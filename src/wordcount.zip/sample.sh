sed -i -e 's/\r$//' setup.sh
sed -i -e 's/\r$//' run.sh
