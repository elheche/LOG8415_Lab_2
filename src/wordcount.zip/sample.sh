sed -i -e 's/\r$//' setup.sh
