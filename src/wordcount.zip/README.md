# WordCount Setup Steps
1- Copy setup.sh and WordCount.java to your EC2 instance.\
2- Execute: ./setup.sh